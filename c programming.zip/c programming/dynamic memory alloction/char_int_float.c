#include<stdio.h>
int main()
{
int i;
float f;
char c;
//printf("Enter the number:\n");
//scanf("%d",&i);
//printf("%d\n",i);
//printf("Enter the float value:\n");
//scanf("%f",&f);
//printf("%f\n",f);
//printf("Enter the char:\n");
//scanf("%s",&c);
//printf("%c\n",c);

scanf("%d,%f,%c",i,f,c);
printf("The integer is: %d\n The float is: %f\n The character is: %c",i,f,c);

}
