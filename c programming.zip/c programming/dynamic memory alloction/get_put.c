// printing the user given input using the unformatted input and out put statements!!!!

#include<stdio.h>
int main()
char c;
c=getchar();
putchar(c);

printf("\n");

char d[8]= "spoorti";
puts(d);
puts("V H");
}
