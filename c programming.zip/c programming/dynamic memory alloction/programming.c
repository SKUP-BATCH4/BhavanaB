#include<stdio.h>
#define $ 365.12
char s=10;
int main()
{
   int a,b,sum;
   printf("enter the values of a and b:");
   scanf("%d ",&a,&b);
   printf("%d %d",a,b);
   scanf("%d %d ",&b);
   printf("%d %d",a,b);
}
