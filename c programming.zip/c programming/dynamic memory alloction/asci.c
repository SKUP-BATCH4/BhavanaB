#include<stdio.h>
int main()
{

   // char c;
   // int m=3;
    //float f=8.7;
    //double l=48595.6878973895647956492786349264;
    //signed short s=
    printf("%i\n",5);
     //printf("%c",c);
     printf("%f\n",12.5);
     printf("%e\n",56.78);
     printf("%E\n",4.6);
     printf("%o\n",743);
    printf("%xc\n",46);
    printf("%Lf\n",74875.4738678);



}
