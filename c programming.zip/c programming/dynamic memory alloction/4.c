// to print the value given by the user

#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter the value u want to give for a and b: ");
    scanf("%d%d",&a,&b);
    printf("%d \v%d",a,b);
}
