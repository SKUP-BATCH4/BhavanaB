#include<stdio.h>
int main()
{
     int a,b,sum;
     printf("Enter a num:");
     scanf("%d,%d",&a,&b);
     sum=a+b;
     a==b?printf("%d",sum*3):printf("%d",sum);
}
