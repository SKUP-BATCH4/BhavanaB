#include<stdio.h>
int main()
{
     int a;
     printf("Enter a num:");
     scanf("%d",&a);
     (a%20==1)||(a%20==2)?printf("spoorti"):printf("Not spoorti");
}
