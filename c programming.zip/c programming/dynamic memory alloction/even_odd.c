#include<stdio.h>
int main()
{
     char a;
     printf("Enter a num:");
     scanf("%c",&a);
     a%2==0?printf("Even"):printf("Odd");
     printf("cmd");
}
