#include<stdio.h>
int main()
{
 int z=2147483648;
 printf("%d",z);

 int a=10,b=10;
 a=-b;
 printf("%d",a);

 return 0;
}
