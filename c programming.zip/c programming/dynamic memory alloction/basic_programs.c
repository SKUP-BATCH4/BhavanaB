#include<stdio.h>
int main()
{
    int a=10, b=50, sum;
    sum=a+b;
    printf("%d",sum);
    return 0;
}
