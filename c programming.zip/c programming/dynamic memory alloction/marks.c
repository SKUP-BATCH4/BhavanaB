#include<stdio.h>
int main()
{
    int m,s,ss,e,k;
    printf("enter the marks of maths:\n");
    scanf("%d",&m);
    printf("enter the marks of science:\n");
    scanf("%d",&s);
    printf("enter the marks of ss:\n");
    scanf("%d",&ss);
    printf("enter the marks of english:\n");
    scanf("%d",&e);
    printf("enter the marks of kannada:\n");
    scanf("%d",&k);

    printf("\n");
    printf("\n");
    printf("********************************\n");
    printf("__________MARKS SHEET__________\n");
    printf("\n");
    printf("         VIKRAM G V             \n");
    printf("\n");
    printf("********************************\n");
    printf("Maths marks            :%d\n",m);
    printf("Science marks          :%d\n",s);
    printf("Social Science marks   :%d\n",ss);
    printf("English marks          :%d\n",e);
    printf("Kannada marks          :%d\n",k);
}
