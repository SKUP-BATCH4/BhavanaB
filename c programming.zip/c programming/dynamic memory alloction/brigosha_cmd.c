#imclude<stdio.h>
int main()
{
    printf("hello brigosha");
}
