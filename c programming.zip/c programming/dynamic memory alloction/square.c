#include<stdio.h>
int main()
{
int x;
printf("Enter the number:\n");
scanf("%d",&x);
printf("the square of a number is:%d\n",x*x);
printf("the cube of a number is:%d\n",x*x*x);
}
