#include<stdio.h>
#include<math.h>
int main()
{
//    prinf("and or xor operations!!!!!!!!\n");
//    int a=65, b=74;
//    int x=89, y=124;
//    printf("The and operator of %d and %d is: %d\n",a,b,a&b);
//    printf("The or operator of %d and %d is: %d\n",a,b,(a|b));
//    printf("The xor operator of %d and %d is: %d\n",a,b,(a^b));
//printf("\n");
//    printf("The and operator of %d and %d is: %d\n",x,y,x&y);
//    printf("The or operator of %d and %d is: %d\n",x,y,x|y);
//    printf("The xor operator of %d and %d is: %d\n",x,y,x^y);

//    printf("left_shift operations!!!!!!!!\n");
//    int x=40;
//    //printf("%d\n",x<<2);
//    printf("%d\n",x<<-3);
//
//    printf("Right_shift operations!!!!!!!!\n");
//    int y=10,m;
//    //char x='a';
//    //printf("%c\n",x>>1);
//    printf("%d\n",y>>2);
//    m=y/(pow(2,2));
//    printf("%d",m);

    printf("Negation operations!!!!!!!!\n");
    char x='b';
    printf("%d",~x);

}
