#include<stdio.h>
int main()
{

    char a='a',b='b',x;
    x=a>b?a:b;
    printf("%c",x);
}
