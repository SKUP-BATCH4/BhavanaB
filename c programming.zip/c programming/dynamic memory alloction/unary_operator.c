//#include<stdio.h>
//int main()
//{
//    float x=0;
//    printf("%f",!(x));
//}


                                // BINARY
#include<stdio.h>
//#define a 100
int main()

{
     int a=500, b=60;
//    printf("The sum of %f and %f is:%f\n",a,b,a+b);
//    printf("The multiplication of %f and %f is:%f\n",a,b,a*b);
//    printf("The substarction of %f and %f is:%f\n",a,b,a-b);
//    printf("The division of %f and %f is:%f\n",a,b,a/b);
//    printf("The reminder of %f and %f is:%f",a,b,a%b);
//    printf("%d\n",a=a+8);
//    printf("%d\n",a-=20);
//    printf("%d\n",a/=20);
//    printf("%d\n",a*=20);
//    printf("%d",(a%=21));

printf("%d\n",a>b);
printf("%d\n",a<8);
printf("%d\n",a>=8);
printf("%d\n",a<=8);
printf("%d\n",a==8);
printf("%d\n",a!=8);

}
