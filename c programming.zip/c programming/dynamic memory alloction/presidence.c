#include<stdio.h>
int main()
{
    char a,b;

    printf("%d",a||b);
}
