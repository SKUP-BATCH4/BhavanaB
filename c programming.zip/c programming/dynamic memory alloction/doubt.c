#include<stdio.h>
int main()
{
int x,y=16,z=20;
scanf("%d",&x);
//printf("%d",x++ - --y + ++z - --y - ++x);
printf("%d %d %d\n",x,x++,++x);

}

