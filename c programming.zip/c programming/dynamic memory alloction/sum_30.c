#include<stdio.h>
int main()
{
     int a, b;
     printf("Enter 2 num:");
     scanf("%d,%d",&a,&b);
     (a+b)==30||(a==30)||(b==30)?printf("True"):printf("False");

}
