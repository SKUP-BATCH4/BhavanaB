#include<stdio.h>
int main()
{/*
    int n1,n2, mul;
    printf("Enter Number 1:");
    scanf("%d",&n1);
    printf("Enter Number 2:");
    scanf("%d",&n2);
    mul=n1*n2;
    printf("The multiplication of %d and %d is: %d",n1,n2,mul);
    */
    int s=7;
    float a,b,mul,sum;
    printf("enter a:");
    scanf("%f",&a);
    printf("enter b:");
    scanf("%f",&b);
    mul=a*b;
    printf("multiplication is :%f\n",mul);
    sum=mul*s;
    printf("%f",sum);
}

