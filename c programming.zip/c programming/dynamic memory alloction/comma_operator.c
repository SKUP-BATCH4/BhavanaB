#include<stdio.h>
int main()
{
    int a=2,b=10;
//    int x=(a++,a--,++a,a++);
//    //x=(printf("hello\n"),printf("%d\n",a));
//    int m=(b++,++b);
//    int k=(printf("%d\n",b++),printf("%d\n",++b),++b );
//    printf("%d",k);

//    printf("%d\n",b);
//    printf("%d\n",x);
//    a++;
//    printf("%d\n",x);
//    printf("hello\n");
//    printf("%d\n",x);

//printf("%d,%d,%d",a,a++,++a);
int y=(10+2)/(1&0)-(11-2)+(0||0);
printf("%d",y);
}
