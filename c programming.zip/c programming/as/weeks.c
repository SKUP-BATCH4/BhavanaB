#include<stdio.h>
void main()
{
    int d;
    bool b;
    printf("Enter the day: 0=sunday, 1=monday, 2=tuesday, 3=wednesday, 4=thursday, 5=friday and 6=saturday:");
    scanf("%d",&d);
    printf("Enter true=1 or false=0:");
    scanf("%d",&b);
}
