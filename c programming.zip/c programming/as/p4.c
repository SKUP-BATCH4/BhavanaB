#include"p5.c"
int x=2;
void main()
{
        printf("%d",display());
}
