int main()
{
    int x=22;
    if(x%2==0)
    {
      x=x<<=1;
      printf("%d",x);
    }
}
