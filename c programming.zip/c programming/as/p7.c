#include<stdio.h>
#include"p5.c"
extern int x;
x++;
int display()
{
    return x;
}
void main()
{

}
