#include<stdio.h>

int x=10;
void main()
{
    display();
}
