#include<stdio.h>
 int x=2;
int main()
{
        printf("%d",display());

}
