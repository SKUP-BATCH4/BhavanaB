 // register int x=9;
   // static int y=10;
int main()
{
    printf("%d",display());
    printf("%d",dis());
}
int display()
{
    int y;
    y+=10;
    return y;
}
int y=10;
int dis()
{
    int x;
    return x;
}
int x=9;
