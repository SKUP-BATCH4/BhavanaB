#include<stdio.h>
int main()
{
    int a[5];
    int *p[5];
    for(int i=0;i<5;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<5;i++)
    {
        p[i]=&a[i];
        printf("%d %d\n",p[i],*p[i]);
    }
}
