#include<stdio.h>
//`int fun(int *, char *);
struct abc
{
    //int a;
    char b[20];
}v;
int main()
{
    char b[20];
 struct abc v={"kavyaaaa"};
 fun(v);
}
int fun(struct abc v)
{
    //v.a=10;
   // v.b='a';
    printf("%s",v.b);
}
