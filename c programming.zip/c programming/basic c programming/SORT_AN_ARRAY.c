#include<stdio.h>
int array(int a[],int n);
 int main()
 {
     int i,n;
     printf("Enter the size of the array ;");

     scanf("%d",&n);
     int a[n];
     printf("Enter the array Elements :");
     for(i=0;i<n;i++)
     {
         scanf("%d",&a[i]);
     }
     array(a,n);
 }

 int array(int a[],int n)
 {
     for(int j=0;j<n-1;j++)
     {
         for(int k=j+1;k<n;k++)
         {
             if(a[j]>a[k])
             {
             int temp=a[j];
             a[j]=a[k];
             a[k]=temp;
             }
     }
 }
 printf("sorted elemnnts :");
 for(int i=0;i<n;i++)
     {
         printf("%d\n",a[i]);
     }
 }
