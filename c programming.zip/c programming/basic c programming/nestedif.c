#include<stdio.h>
int main()
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    if(a>b)
    {
        if(a>c)
        {
            printf("larger");
        }
        else
        {
            printf("smaller");
        }
    }
    else
    {
        printf("smallest");
    }
}
