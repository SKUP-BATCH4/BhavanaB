#include<stdio.h>
int main()
{
    int a;
    printf("Enter the number : ");
    scanf("%d",&a);
    (a>=10)?printf("greater than or equal to 10"):printf("less than 10");
}
