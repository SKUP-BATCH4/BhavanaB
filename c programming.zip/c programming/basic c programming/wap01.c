#include<stdio.h>
#include<stdbool.h>
int main()
{

    bool a;
    int x;
    scanf("%d",&x);
    a=x;
    printf("%d",a);

}
