#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the values of a,b,c :");
    scanf("%d%d%d",&a,&b,&c);
    FILE *fp;
    fp=fopen("C:/Users/lenovo/Documents/3sum.txt","w");

    if(a!=b && b!=c && a!=c)
    {
        fprintf(fp,"The sum is :%d",a+b+c);
    }

    else if(a==b && a==c)
    {
        fprintf(fp,"0");
    }
    else
    {
        if(a==b)
         {
              fprintf(fp,"The sum is :%d",c);
         }
         else if(a==c)
         {
              fprintf(fp,"The sum is :%d",b);
          }
        else
         {
             fprintf(fp,"The sum is :%d",a);
        }
    }
fclose(fp);
}
