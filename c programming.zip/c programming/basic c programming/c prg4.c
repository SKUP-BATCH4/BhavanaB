#include<stdio.h>
int main()
{
    char c,h[10];
    c=getchar();

    gets(h);
    puts(h);
    putchar(c);
    return 0;
}
