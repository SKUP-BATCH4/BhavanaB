#include<stdio.h>
void sum(int,int);
void main()
{
   int a,b,s;
   scanf("%d %d",&a,&b);
   int (*p)(int,int)=sum;
   (*p)(a,b);


}
void sum(int a, int b)
{
    printf("%d", a+b);
}
