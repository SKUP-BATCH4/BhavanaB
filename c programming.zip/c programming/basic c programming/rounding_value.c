#include<stdio.h>
int sum(int,int,int);
int round(int);
int main()

{

//    float a=19.1;
//    printf("%f\n",ceil(a));
//    printf("%f\n",floor(a));
//
//}
    FILE *fp;
    fp=fopen("C:/Users/lenovo/Documents/printgsum.txt","w");
    int a,b,c;
    printf("Enter the value of a,b,c :");
    scanf("%d %d %d",&a,&b,&c);
    int q=round(a);
    int w=round(b);
    int e=round(c);
    fprintf(fp,"The sum is:");
    int h=sum(q,w,e);
    fprintf(fp,"%d",h);

    fclose(fp);
}
int round(g)
{
    int x=g%10;
    if(x>=5)
    {
        int z=10-x;
        return g+z;
    }
    else
    {
        return g-x;
    }
}

int sum(q,w,e)
{
return q+w+e;
}
