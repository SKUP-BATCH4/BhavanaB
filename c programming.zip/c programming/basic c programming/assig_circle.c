#include<stdio.h>
#define pi 3.142
int main()
{

    float r,area,crc;
    printf("enter the radius of circle : ");
    scanf("%f",&r);

    area=p*r*r;
    crc=2*pi*r;
    printf("area of the circle is %f\n",area);
    printf("crc of the circle is %f",crc);
}
