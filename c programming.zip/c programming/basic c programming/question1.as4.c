#include<stdio.h>
int i,c,size,s=0;

int arg[0],arg2[11];

printf("enter the value for arbitration %d",arg[0]);
//scanf("%d",arg[0]);

for(int i=0;i<arg[0];i++)
{
printf("%d",arg[i]);
}
c++;
}
printf("enter the value for arbitration %d",c);
    scanf("%d ",&arg2);

for (int i=0;i<arg2[11];i++)
{
printf("%d",arg2[i]);
}

}
for (i=0;i<arg2[i];i++){
    if(arg[i]==0 && arg2[i]==0){
    i++;
    else if (arg1[i]==0 && arg2[i]!==0){
        return 0;}
    else if (arg1[i]==1 && arg2[i]==1){
        i++;}
    else
        return 1;
}
}

main()
{
    int size ,msg;
    printf("enter the number of can massage" );
    scanf("%d",&size);

}

