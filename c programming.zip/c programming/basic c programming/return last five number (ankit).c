#include<stdio.h>
int ret(int);
int main()
{
int a;
printf("Enter the Number:");
scanf("%d",&a);
printf("%d",ret(a));
}
int ret( a){
int r;
r=a/10;
return r;
}

