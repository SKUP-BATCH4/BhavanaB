#include<stdio.h>
#define PI 3.42

int main(){
int a;
int b;
//float c=3.99;
//long long int f=8;
//float r=3;
//float area;
//area=PI*r*r;
//printf("%f",PI);
scanf("%d\n %d",&a,&b);
printf("%d %d",b);

return 0;
}

