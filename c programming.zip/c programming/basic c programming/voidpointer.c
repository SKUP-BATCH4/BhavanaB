#include<stdio.h>
int main()
{
    void *vp;
    int a=5;
    float b=8.97;
    char c='j';
    //vp=&a;
    //vp=&b;
    vp=&c;
    //printf("%d\n",*(int*)vp);
    //printf("%f\n",*(float*)vp);
    printf("%c",*(char*)vp);
}

