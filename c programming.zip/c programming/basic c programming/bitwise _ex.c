 #include<stdio.h>
 int main()
 {
//
//     int a=65,b=74;
//     printf("%d\n",a&b);
//     printf("%d\n",65|74);
//     printf("%d\n",a^b);
//     int a=116,b=124;
//     printf("%d\n",a&b);
//     printf("%d\n",a|b);
//     printf("%d\n",a^b);

     int a=124,b=89;
     printf("%d\n",a&b);
     printf("%d\n",a|b);
     printf("%d\n",a^b);
     printf("%d\n",a<b);
     printf("%d\n",a>b);
     printf("%d\n",a=b);
     printf("%d\n",a>=b);


 }
