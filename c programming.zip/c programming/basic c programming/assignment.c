#include<stdio.h>

struct customer
{
    int acc_no;
    int ph_no;
    char name[20];
    int aadhar;
    int pan;
} ;
void create(struct customer[],int );
void display(struct customer[],int);
int search(struct customer[], int, int);

int main()
{
    struct customer data[20];
    int n,choice,acc_no,index,ph_no,pan,aadhar;
    printf("number of customer record u want to enter:\n");
    scanf("%d",&n);
    create(data,n);
    do
    {
    printf("\n...........Banking system..............\n");
    printf("press 1 to display all records:\n");
    printf("press 2 to search\n");
    printf("press 0 to exit\n");
    printf("/n enter choice(0-2):");
    scanf("%d",&choice);
    switch(choice)
    {
    case 1:
        display(data,n);
        break;
    case 2:
        printf("enter phone number to search");
        scanf("%d",&ph_no);
        index=search(data,n,ph_no);
        if(index==-1)
        {

            printf("record not found");
        }
        else
        {

            printf("phone number: %d\n name:%s\n pan:%d\n aadhar:%d",data[index].ph_no,data[index].name,data[index].pan,data[index].aadhar);

        }
        break;
    }
}
while(choice!=0);
return 0;
}
void create(struct customer list[80], int s)
{
    int i;
    for(i=0;i<s;i++)
    {
        printf("enter account number");
        scanf("%d",&list[i].acc_no);
        printf("enter name:");
        scanf("%s",&list[i].name);
        printf("enter phone number");
        scanf("%d",&list[i].ph_no);
        printf("enter pan card number:");
        scanf("%d",&list[i].pan);
        printf("enter aadhar number:");
        scanf("%d",&list[i].aadhar);
    }
}

void display(struct customer list[80],int s)
{
    int i;
    printf("\n\n ac_no \t name \t ph_no \t pan \t aadhar\n");
    for(i=0;i<s;i++)
    {
        printf("%d\t %s\t %d\t %d\t %d\n",list[i].acc_no,&list[i].name,list[i].ph_no,list[i].pan,list[i].aadhar);

    }
}

int search(struct customer list[80], int s,int num)
{
    int i;
    for(i=0;i<5;i++)
    {
        if(list[i].ph_no==num)
        {
            return 1;
        }
    }
    return -1;
}
