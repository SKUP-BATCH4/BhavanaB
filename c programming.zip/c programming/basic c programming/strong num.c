7#include<stdio.h>
int main()
{
    int i, n,rem;
    scanf("%d",&n);
   sum1(n);
}
int sum1(int n)
  {
    int sum=0,temp=n;
    while( n!=0)
    {
        int rem=n%10;
        //fact(n);
         n=n/10;
        sum=sum+fact(rem);

    }

     if(sum==temp)
    {
        printf("strong number");
    }
    else{
        printf("not strong no");
    }
}

  int fact(int num)
  {
      int fact=1,i;
        for( i=1;i<=num;i++)
        {
            fact=fact*i;
}
return fact;
        }

