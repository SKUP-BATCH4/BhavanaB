
#include<stdio.h>
int main()

{
    int a=2147483648;
    printf("%d",a);
}
