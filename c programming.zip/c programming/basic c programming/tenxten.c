#include<stdio.h>
int main()
{
    /*int a[10][10]={{0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0},
    {0,0,0,0,0,0,0,0,0,0}};*/
    int a[10][10];
    //nested for loop for initializing all values to 0
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<10;j++)
        {
            a[i][j]=0;
        }
    }
    printf("Enter the values: \n");
    for( int i=0;i<10;i++)
    {
        scanf("%d",&a[i][9]);

    }
    printf("\n---------------------\n");
    for(int i=0;i<10;i++)
    {

        for(int j=0;j<10;j++)
        {

            printf("\t%d",a[i][j]);
        }

        printf("\n");

    }
    return 0;
}
