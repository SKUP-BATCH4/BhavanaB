#include<stdio.h>
int main()
{

    int a;
    printf("Enter the no. : ");
    scanf("%d",&a);
    printf("square=%d\n cube=%d",a*a,a*a*a);

}

