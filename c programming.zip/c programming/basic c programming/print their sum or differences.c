#include<stdio.h>
int main()
{
int a,b;
printf("Enter the two integers");
scanf("%d %d",&a,&b);
a+b==6||b-a==6?printf("true"):printf("false");

}
