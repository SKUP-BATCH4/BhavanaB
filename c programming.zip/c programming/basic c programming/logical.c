#include<stdio.h>
int main()
{

//    float a=0.00001zas,b=6.7,c=2.9;
    int a=4,b=6;
    printf("%d",a^b);
//    printf("%d\n",a&&b);
//    printf("%d\n",a||b);
//    printf("%d\n",(a<b)&&(b<c));
//    printf("%d\n",(a<b)||(b<c));
//    printf("%d\n",0&&1);
//    printf("%d\n",2||0);
}
