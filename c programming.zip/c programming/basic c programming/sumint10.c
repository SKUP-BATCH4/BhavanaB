#include<stdio.h>
int main()
{
    int i,a,sum=0;
    for(i=1;i<=10;i++)
    {
        scanf("%d",&a);
        sum=sum+a;
    }
    printf("The total sum is %d",sum);
}
