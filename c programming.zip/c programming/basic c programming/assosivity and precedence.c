#include<stdio.h>
int main()
{
    int y;
//y=10/2+15-5*(1||0)+(10/2)+10*3;
y=(10/2)/(1&0)-(11-2)+(0||0);
    printf("%d",y);
}
