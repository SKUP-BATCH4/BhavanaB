#include<stdio.h>
int main()
{
    int a,b,c,h;
    scanf("%d %d %d",&a,&b,&c);
    h=lottery(a,b,c);
    printf("result = %d",h);

}
int lottery(int a, int b, int c)
{
    int e,f,g;
    e=a+b;
    f=b+c;
    g=a+c;


    if(e==10||f==10||g==10)
        return 10;
    else if((e+10)==f||(e+10)==g)
        return 5;
    else
        return 0;
}
