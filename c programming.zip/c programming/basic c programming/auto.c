#include<stdio.h>
#include "auto_display.c"
int drama()
{
 extern int x;
 x++;
 printf("%d\n",x);
 return x;
}












