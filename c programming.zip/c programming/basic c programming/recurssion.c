#include<stdio.h>
int main()
{
    int n=5;
    printf("%d",func(n));
}

int func(int n)
{
    if(n==1)
        return 1;
    else
        return 1+func(n-1);
}
