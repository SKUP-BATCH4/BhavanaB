#include<stdio.h>
int main()
{
  int age;
  printf("Enter the age:");
  scanf("%d",&age);
  if (age>=40)
  {
      if(age<60)
        printf("you are eligible for DL");
      else
        printf("your not eligible dl");
  }



  else
    printf("your not eligible dl");

}
