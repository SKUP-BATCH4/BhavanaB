#include<stdio.h>
#include<process.h>
int main()
{

system("SHUTDOWN -S");
}
