#include<stdio.h>
#include<stdbool.h>
bool prime(int);
    int main()
    {
        int a;
        printf("Enter the prime no:");
        scanf("%d",&a);
        printf("%d",prime(a));
    }
    bool prime(int a)
    {
        int count=0;
       for(int i=1;i<=a;i++)
        {
            if(a%i==0)
                count++;
        }
        if(count==2)
            return true;
        else
            return false;
    }


