#include<stdio.h>
int min(int [],int );
int max(int [],int );
int main()
{
    int x,i;
    printf("Enter the size of the array: ");
    scanf("%d",&x);
    int a[x];
    for(i=0;i<=x;i++)
    {
        scanf("%d",&a[i]);
    }
    printf("Minimum is : %d\n",min(a,x));
    printf("Maximum is : %d\n",max(a,x));

}

int min(int b[],int x)
{
    int min=b[0];
    int i;
    for(i=0;i<=x;i++)
    {
        if(b[i]<min)
        {
            min=b[i];

        }
    }
     return min;
}
int max(int a[],int x)
{
    int i;
    int max=a[0];

        for(i=0;i<=x;i++)
    {
        if(a[i]>max)
        {
            max=a[i];

        }

    }
     return max;


}
