#include<stdio.h>
int main()
{
int a;
printf("Enter the floor No:");
scanf("%d",&a);
switch(a)
{
case 1:printf("First Floor");
break;
case 2:printf("Second Floor");
break;
case 3:printf("Third Floor");
break;
case 4:printf("Fourth Floor");
break;
default:printf("Invalid Flor No:");
}
}
