 #include<stdio.h>
int main()
{
    int*ptr;
    int n,i;
    n=5;
    printf("enter the elements:");
    scanf("%d",&n);
    printf("elements are %d\n",n);
    ptr=(int*)calloc(5, sizeof(int));
    if(ptr==NULL)
    {
        printf("memory allocated");
    }
    else
        {
            printf("memory allocated in calloc\n");
                  for(i=0;i<5;++i)
                    ptr[i]=i+1;
        }
        printf("the array elements:");
        for(i=0;i<5;++i)
            {
                printf("%d",ptr[i]);

            }
                n=10;
                printf("\n\n size of arrray:%d\n",n);
                ptr=realloc(ptr,n*sizeof(int));
                printf("memory reallocated\n");
                for(i=5;i<10;i++)
                {
                   ptr[i]=i+1;
                }
                printf("the array elements\n:");
                for(i=0;i<10;i++)
                {
                    printf("%d",ptr[i]);




                }







}
