#include<stdio.h>
int main()
{
int a=10;
int*ptr1,**ptr2,***ptr3,****ptr4;
ptr1=&a;
ptr2=&ptr1;
ptr3=&ptr2;
printf("%d%d%d",*ptr1,**ptr2,***ptr3);

}
