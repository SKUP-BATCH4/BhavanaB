#include<stdio.h>
int main()
{
char*str[5]={"ajy","vijy",""anmol"};
for(int i=0;i<5;i++)
{
printf("%d%d\n",str[i],str[i]);
}
}
