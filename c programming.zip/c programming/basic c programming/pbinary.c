#include<stdio.h>
int main()
{

    int a=10.3,b=0.3;
    printf("%d\n",a+b);
    printf("%d\n",a-b);
    printf("%d\n",a*b);
    printf("%d\n",a/b);
//    printf("%d\n",a%b);

}
