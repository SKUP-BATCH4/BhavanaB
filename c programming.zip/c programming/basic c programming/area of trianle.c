#include<stdio.h>
float area(float a,float b)
{


float r;
r=0.5*a*b;
return r;
}
int main()
{
float a,b;
scanf("%f%f",&a,&b);
printf("%f",area(a,b));


}
