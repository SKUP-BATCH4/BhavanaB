#include<stdio.h>
typedef struct vak
{
    char b,c,d;


    int t,g;

}ankt;
main()
{
    ankt r={'i','j','y',6,3.3,};
    printf("%d",sizeof(r));
}
