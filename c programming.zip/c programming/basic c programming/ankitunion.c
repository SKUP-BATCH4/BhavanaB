#include<stdio.h>
typedef union student{
int n;
float cgpa;
char grade;
}std;
int main(){
std v={12,1.4,'a'};
printf("%d\n%f\n%c\n",n,cgpa,grade);
s
