#include<stdio.h>
int main()
{

    char c,h;
    printf("Enter the character : ");
    scanf("%c %c",&c,&h);
    printf("character is %c %c \n",c,h);
    /*printf("------------\n");

    printf("Enter the character : ");
    scanf("%c",&h);
    printf("character is %c \n",h);*/
    return 0;

}



