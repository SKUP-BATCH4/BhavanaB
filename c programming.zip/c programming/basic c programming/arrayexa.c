#include<stdio.h>
int main()
{
    int b[5]={1,2,3,4,5};
    printf("%d %d",&b[0],&b[1]);
}
