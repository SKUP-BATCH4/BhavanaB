#include<stdio.h>
int main()
{
    char *str[5]={"Porsche","Ferrari","Tata","Audi","BMW"};
    for(int i=0;i<5;i++)
    {
        printf("%d %s\n",str[i],str[i]);
    }

}
