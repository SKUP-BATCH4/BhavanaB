#include<stdio.h>
int main()
{
int p,r,t;
printf("Enter the two no:");
scanf("%d%d%d",&p,&r,&t);
printf("%d",add(p,r,t));
}
int add (int p,int r,int t)
{
int si;
si=p*r*t/100;
return si;
}
