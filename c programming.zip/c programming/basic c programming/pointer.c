#include<stdio.h>
int main()
{

    int a=20;
    int* ptr=&a;
    int** ptr1=&ptr;
    int ***ptr2=&ptr1;
    int ****ptr3=&ptr2;
    printf("values :%d %d %d %d\n",****ptr3,***ptr2,**ptr1,*ptr);
    printf("address : %x %x %x %x",ptr3,ptr2,ptr1,ptr);
    }
