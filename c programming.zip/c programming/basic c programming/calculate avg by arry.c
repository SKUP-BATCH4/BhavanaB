#include<stdio.h>
main()
{
    int i,x,sum=0;
    int a[5];
   // scanf("%d",&n);
    for(i=0;i<5;i++)
    {
        scanf("%d",&a[i]);
    }

    for(i=0;i<5;i++)
    {
       printf("%d\n",a[i]);
       sum=(sum+a[i]);
    }

    x=sum/5;
    printf("%d",x);

}
