#include<stdio.h>
int fun(int,int);
int ankit(int*,int*);
int main()
{
    int x=20,y=10;
    fun(x,y);
    ankit(&x,&y);
    printf("%d\n%d\n",x,y);
}
int fun(int x,int y)
{
    printf("%d\n",x-y);
}
int ankit(int*x,int*y)
{
    printf("%d\n",(*x)/(*y));
}

