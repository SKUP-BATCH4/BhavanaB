#include<stdio.h>
int main()
{

    int a;
    float b;
    char c;
    int*ptr1=&a;
    scanf("%d %f %c",&a,&b,&c);
    float*ptr2=&b;
    char*ptr3=&c;
    printf("%d %f %c\n",*ptr1,*ptr2,*ptr3);
    printf("address: %x %x %x",ptr1,ptr2,ptr3);
}
