#include<stdio.h>
#include<string.h>
char* reverse();


int main()
{
    reverse();

}
char* reverse()
{
    char a[10];
    int i;
    gets(a);


   int  x=strlen(a);
   //printf("%d",x);
    for(i=x;i>=0;i--)
    {
       printf("%c",a[i]);
    }
  //  printf("%s",b);
}
