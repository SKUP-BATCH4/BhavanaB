#include<stdio.h>
void main()
{
    int i;
    int a[3];
    printf("Enter the 3 values : ");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
//    for(int i=0;i<3;i++)
//    {
//        printf("%d\t",a[i]);
//    }

    if(a[0]==6||a[2]==6)
        printf("True");
    else
        printf("False");


}
