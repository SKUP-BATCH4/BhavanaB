#include<stdio.h>
void main()
{
    int i;
    int a[3];
    printf("Enter the 3 values : ");
    for(i=0;i<3;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<3;i++)
    {
        if(a[i]==2&&a[i+1]==3)
        {
            a[i+1]=0;
        }
//        else
//            continue;
    }
    printf("The values : ");
    for(int i=0;i<3;i++)
    {
        printf("%d ",a[i]);

    }


}

