#include<stdio.h>
int func(int,int);

int main()
{
    int a;
    scanf("%d",&a);
    int n;
    scanf("%d",&n);
    int arr[n];
    printf("%d",func(a,arr));
}
int binary()
{
    long int i=1,rem,bin,hex=0;
    scanf("%d",&bin);
    while(bin!=0)
    {
        rem=bin%10;
        hex=hex+rem*i;
        i=i*2;
        bin=bin/10;


    }
    return hex;

}

int func(int a,int arr[])
{

   for(int i=0;i<8;i++)
    {
       for(int j=0;j<8;j++)
       {


         if(arr[i]==arr[j])
            return arr[i];

         else if(arr[i]==0 && arr[j]==1)
            return arr[i];
            continue;
         else if(arr[i]== 1 && arr[j]==0)
            return arr[j];
            continue;
         else
                return a[i];
       }

    }

}
