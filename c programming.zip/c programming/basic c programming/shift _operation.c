#include<stdio.h>
int main(){

  int a=10;
  int b=30;
//  printf("%d\n",a<<2);
//  printf("%d\n",a);
//  printf("%d\n",a<<3);
//  printf("%d\n",a);
//
//  printf("\n");

  printf("%d\n",b<<1);
  printf("%d\n",b);
  printf("%d\n",b>>2);
  printf("%d\n",b);

}
