#include<stdio.h>
int main()
{
int*p[5];
int a=10, b=20, c=30;
p[0]= &a;
p[1]= &b;
p[2]= &c;
printf("%d %d %d\n", p[0], p[1], p[2]);
printf("%d, %d, %d", *p[0], *p[1], *p[2]);
}
