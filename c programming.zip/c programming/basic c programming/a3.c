#include<stdlib.h>
struct node
{
    int data;
    struct node *link;
    struct node *ptr;
       struct node *current;
};
void main()
{
    int data;
    struct node *head='\0';
    struct node *ptr='\0';

    head=(struct node *)malloc(sizeof(struct node));
    head->data=10;
    head->link='\0';
    fun(ptr,data);
    printf("%d",ptr->data);
}
int fun(struct node *ptr,int data)
{
    struct node *head='\0';
    struct node *current='\0';
    current=(struct node *)malloc(sizeof(struct node));
    current->data=20;
    current->link='\0';
    head->link=current;



}
