#include<stdio.h>
#include<stdlib.h>
struct node
{

    int data;
    struct node*link;
};
void main()

{

    struct node *head=NULL;
    struct node *current;
    struct node *ptr;

    head=(struct node*)malloc(sizeof(struct node));
    head->data =10;
    head->link=NULL;

     current=(struct node*)malloc(sizeof(struct node));
    current->data =20;
      current->link=NULL;
       head->link=current;

      current=(struct node*)malloc(sizeof(struct node));
     current->data =30;
      current->link=NULL;
   head->link->link=current;

   current=(struct node*)malloc(sizeof(struct node));
     current->data =40;
      current->link=head;

    ptr=(struct node *)malloc(sizeof(struct node));
   ptr->link=current->link;
   current->data=ptr->link;
   printf("\n%d",ptr->data);


}





