#include<stdio.h>
int add0();
void add1();
int main()
{
int p,r,t;
printf("Enter the no:");
scanf("%d%d%d",&p,&r,&t);
printf("%d",add0());
add1();
printf("%d",add2(p,r,t));
add3(p,r,t);
}
int add0()
{
int p=80,t=2,r=5,s;
s=(p*r*t)/100;
return s;
}


void add1()
{
  int p=80, t=2, r=5, s;
  s=(p*r*t)/100;
  printf("%d",s);

}

int add2(int p, int r ,int t)
{
 int s;
  s=(p*r*t)/100;
      return s;

}

void add3(int p, int r, int t)
{
   int s;
  s=(p*r*t)/100;
  printf("%d",s);




}
