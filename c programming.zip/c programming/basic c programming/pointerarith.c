#include<stdio.h>
int main()
{
//    int a=10;
//    int *p=&a;
//    //int n=2;
//    printf("%d\n",p);
//    printf("%d\n",*p);
//    *p=*p+3;
//    p=p+3;
//    printf("%d\n",p);
//    //printf("%d",*p);

    int a[]={1,2,3,4,5};
    int *p=&a[3];
    int *q=&a[0];
    printf("%d\n",*p);
   //printf("%d\n",q);



    printf("%d\n",--p);
    printf("%d\n",*p);
    printf("%d\n",p);

}
