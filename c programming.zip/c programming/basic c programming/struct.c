#include<stdio.h>
struct vik
{
  int a;
  char c;
  float b;


}v1,v2,v3;

int main()
{
    //struct vik v={13,'l'};
 v1.a=12;
 v1.b=2.33;
 v2.a=23;
 v2.b=3.22;
 v1.c='j';
 v2.c='a';

 printf("%d %.2f %c",v1.a,v1.b,v1.c);


}
