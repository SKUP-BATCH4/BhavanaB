#include<stdio.h>
#include<stdbool.h>
int main()
{
    bool a=true;
    //bool a=false;
    //scanf("%d",&a);
    printf("%B",a);
}
