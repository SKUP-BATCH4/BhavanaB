#include<stdio.h>
int main()
{
    int a;
    printf("Enter a:");
    scanf("%d",&a);
    (a>10)?printf("greater"):printf("lesser");

}
