#include<stdio.h>
int main()
{

    int a=1;
    switch(a)
    {
    case 1:
        printf("f");
    case 2:
        printf("d");

    default:
            printf("e");
    }
}
