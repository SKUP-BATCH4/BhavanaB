#include<stdio.h>
#include<stdbool.h>
bool spaced(int,int,int);
int main()
{
    int a,b,c;
    printf("Enter the values of a,b,c :");
    scanf("%d %d %d",&a,&b,&c);
    printf("%d",spaced(a,b,c));
}

bool spaced(int a, int b, int c)
{
    int x=a-b;
    int y=b-c;
    int z=c-a;
    if(x==y||y==z||z==x)
        return true;
    else
        return false;
}
