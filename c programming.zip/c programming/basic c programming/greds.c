#include<stdio.h>
int main()
{
    int grade;
    printf("enter the grade: ");
    scanf("%d",&grade);
    switch(grade)
    {

        case 81 ... 100: printf("Distiction");
        break;
        case 61 ... 80: printf("First class");
        break;
        case 35 ... 60: printf("pass");
        break;
        case 0 ... 34: printf("Fail");
        break;

        default: printf("better luck next time");

    }
}

