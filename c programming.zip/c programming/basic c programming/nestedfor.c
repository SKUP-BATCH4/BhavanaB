#include<stdio.h>
int main()
{
    int i,j;
    for(i=1;i<=3;i++)
    {
        printf("\n outer loop");
        for(j=1;j<=3;j++)
        {
            printf("\n inner loop");
        }
        printf("\n-----------");
    }
}
