#include<stdio.h>
int main()
{

    int a,b;
     printf("enter the values of a & b :  ");
     scanf("%d %d",&a,&b);
    (a<b)?printf("biggest no. is b=%d ",b):printf("biggest no. is a=%d",a);
}

