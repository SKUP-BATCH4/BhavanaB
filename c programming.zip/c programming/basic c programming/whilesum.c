
#include<stdio.h>
int main()
{
    int i=1,a,sum=0;
    while(i<=10)
    {
        scanf("%d",&a);
        if(a<0)
            //break;
            continue;
        else
            sum=sum+a;
        i++;
    }
    printf("the total sum is %d",sum);
}
