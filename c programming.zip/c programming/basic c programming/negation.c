#include<stdio.h>
int main()
{
    int a=40;

    printf("%d",~a);
}
