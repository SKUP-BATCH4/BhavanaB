#include<stdio.h>
int main()
{
//    char i='a';
//    while(i<='z')
//    {
//        printf("%c\n",i);
//        i++;
//    }

     int i=1;
     while(i)
     {
         printf("%d\n",i);
         i++;
     }
}

