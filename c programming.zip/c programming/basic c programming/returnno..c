#include<stdio.h>
int ret(int);
int main()
{
    int n;
    printf("Enter the Number : ");
    scanf("%d",&n);
    printf("%d",ret(n));
}
int ret(int a)
{
    int r;
    r=a/10;
    return r;
}
