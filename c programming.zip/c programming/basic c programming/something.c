#include<stdio.h>
int main()
{
    int a=0;
    scanf("%d",&a);
    printf("%d %d %d",a,a++,++a);

}
