#include<stdio.h>
int main()
{
    char* a[60];
    scanf("%s",a);
    for(int i=0;i<20;i++)
    {
        if(a[i]==" "||a[i]=="")
        {
            printf("%d\n",i);
            printf("%s",a[i]="skup");
        }
    }
}
