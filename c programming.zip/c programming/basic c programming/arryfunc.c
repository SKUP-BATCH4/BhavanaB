#include<stdio.h>
#include<stdbool.h>
bool arr0(int);
bool arr2();
void arr1(int);
void arr3();
int main()
{
    int a[5];
    for(int i=0;i<5;i++)
    {
        scanf("%d",&a[i]);
    }
   int x=a[0];
    printf("\n%d\n",arr0(x)); //w arg and w retype
    arr1(x);                 //w arg and w/o retype
    printf("\n%d\n",arr2()); //w/o arg and w retype
    arr3();                  //w/o arg and w/o retype
}
//w arg and w retype
bool arr0(int a)
{
    if(a==6)
        return true;
    else
        return false;
}
//w arg and w/o retype
void arr1(int b)
{
    if(b==6)
        printf("True");
    else
        printf("False");
}
//w/o arg and w retype
bool arr2()
{
    int a[5]={6,4,5,5,3};
    if(a[0]==6)
        return true;
    else
        return false;
}
//w/o arg and w/o retype
void arr3()
{
    int a[5]={6,4,5,5,3};
    if(a[0]==6)
        printf("True");
    else
        printf("False");
}
