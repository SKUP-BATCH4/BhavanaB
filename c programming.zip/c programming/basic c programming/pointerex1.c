#include<stdio.h>
int point(int);
int main(){
    int a=100;
    int (*p)(int)=point;
    (*p)(a);

}
int point(int a)
{

    int *p=&a;
    int **p1=&p;
    void *v=&a;
    printf("%d %d %d\n",*p,*p1,**p1);
    printf("%d",*(int*)v);
}
