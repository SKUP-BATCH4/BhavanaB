//hello world program
#include<stdio.h>

int main()
{
    printf("hello world       7666666666666666668\n");

    return 0;
};
