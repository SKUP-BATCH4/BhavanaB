#include<stdio.h>
main()
{
    char a[5];
    int i,count1,count2,b;
    scanf("%s",a);
    char* ptr=&a;
    for(i=0;*ptr!='\0';i++)

    {
        int count1=0;
    if(*ptr=='a'||*ptr==||*ptr==a[2]||*ptr==a[3]||*ptr==a[4])
    {

    count1++;

    else {
            count2++;
    printf("%d",count2);


}

    }
}
