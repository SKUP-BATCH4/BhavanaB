#include<stdio.h>
int main()
{
    int count=0;
    char s[100];
    scanf("%s",&s);
    for(int i=0;s[i]!='\0';i++)

    {

     if(s[i]>='a'&&s[i]<='z'||s[i]>='A'&&s[i]<='Z'||s[i]>='0'&&s[i]<='9')
        continue;
     else
        printf("%c\n",s[i]);
        count++;
    }
    printf("%d",count);
}

