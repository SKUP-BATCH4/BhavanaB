#include<stdio.h>
#include"f2.c"
int dram()
{
    extern int x;
    x++;
    printf("%d",x);
    return x;
}
