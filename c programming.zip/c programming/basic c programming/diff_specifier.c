#include<stdio.h>
void main()
{
    int a;
    float b;
    char c;
    double d;

    scanf("%d",&a);
    /*scanf("%f",&b);
    scanf("%Lf",&d);*/

    printf("%i\n",a);
    printf("%x\n",a);
    printf("%o\n",a);
    printf("%lu\n",a);
    printf("%hi\n",a);
    printf("%hu",a);

    return 0;

}
