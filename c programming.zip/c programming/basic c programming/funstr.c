#include<stdio.h>
#include<string.h>
int main()
{
    char str1[20]="Hello World";
    char str2[20]="Vikram";
    gets(str1);
    gets(str2);
    printf("len1 : %d\n",strlen(str1));
    //printf("%d\n",strcmp(str1,str2));
    printf("lwr1 : %s\n",strlwr(str1));
    printf("upr1 : %s\n",strupr(str1));


     printf("len2 : %d\n",strlen(str2));

     printf("cmp : %d\n",strcmp(str1,str2));
     printf("rev2 : %s\n",strrev(str2));
    printf("rev1 : %s\n",strrev(str1));
    printf("cpy : %s\n",strcpy(str2,str1));

}
