#include<stdio.h>
#include<stdlib.h>
struct node
{

    int data;
    struct node*link;
};
void main()

{
struct node *head=NULL;
struct node *current;
struct node *ptr=head;
head=(struct node*)malloc(sizeof(struct node));
if(head==NULL)
{
    printf("unable");
}
printf("enter node1");
scanf("%d",&data);
head->data=data;
head->link=NULL;

