#include<stdio.h>
float si0(float ,float ,float );
void si1(float ,float ,float );
void si2();
float si3();

int main()
{
    float p,r,t;
    printf("enter the simple interest value\n");
    printf("Enter the principle: ");
    scanf("%f",&p);
    printf("Enter the rate: ");
    scanf("%f",&r);
    printf("Enter the time: ");
    scanf("%f",&t);
    printf("the SI(0) is %.2f\n",si0(p,r,t));
    si1(p,r,t);
    si2();
    printf("the SI(3) is %.2f\n",si3());
}
float si0(float p,float r,float t)
{
    float si=p*r*t/100;
    return si;
}

void si1(float p,float r,float t)
{
    float si=p*r*t/100;
    printf("the SI(1) is %.2f\n",si);;
}

void si2()
{
    float p=100,r=2.5,t=5;
    float si=p*r*t/100;
    printf("the SI(2) is %.2f\n",si);;
}

float si3()
{
    float p=100,r=2.5,t=5;
    float si=p*r*t/100;
    return si;
}
