#include<stdio.h>
int main()
{
    char name[100]="";
    char email[100]="";
    char mob[100]="";
    char sta[100]="";
    printf("Enter name : ");
    gets(name);

    printf("\nEnter email : ");
    gets(email);

    printf("\nEnter your status(C or S) : ");
    gets(sta);


    printf("\nEnter mob : ");
    gets(mob);

    printf("\n");

    puts("Your name : ");
    puts(name);
    printf("\n Your email : ");
    puts(email);
    printf("\n Your mob : ");
    puts(mob);
    printf("\nYour status(C or S) : ");
    puts(sta);



}
