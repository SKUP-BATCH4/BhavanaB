#include<stdio.h>
//int add(int,int);
int main()
{
    int a,b;
    printf("Enter two values: ");
    scanf("%d %d",&a,&b);
    add();
    mul(a,b);
    printf("%d",sub());

    }

//w/o arg and w/o return type
void add()
{
    int x=10,y=20;
    printf("%d\n",x+y);
}
//w arg and w/o return type
void mul(int x, int y)
{
    int x=10,y=20;
    printf("%d\n",x*y);
}
//w/o arg and w return type
int sub()
{
    int x=10,y=20;
    return x-y;
}
