#include<stdio.h>
int main()
{
    int i=0;
    do{
        printf("hello");

    }while(i!=0);
    *
    while(i!=0)
    {
         printf("hello");
    }

}

