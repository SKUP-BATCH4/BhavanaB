#include<stdio.h>
int main()
{

    int a;
    printf("Enter the values a : ");
    scanf("%d",&a);

    (a%20==1||a%20==2)?printf("Vikram"):printf("Bhavana");
}

