#include<stdio.h>
void swap();
int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    swap(a,b);
}
void swap(int d,int e)
{
    int c;
    c=d;
    d=e;
    e=c;
    printf("%d %d",d,e);
}
