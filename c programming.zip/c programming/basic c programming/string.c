#include<stdio.h>
int main()
{
   // char s[10]={'h','e','l','l','o','\0'};
    char a[5]="helloworld";
//    scanf("%s",&a);
//   printf("%s\n",s);
//printf("%s\n",a);
//   gets(a);
 puts(a);
//    for(int i=0;i<sizeof(a);i++)
//    {
//        printf("%c\n",a[i]);
//    }

}
