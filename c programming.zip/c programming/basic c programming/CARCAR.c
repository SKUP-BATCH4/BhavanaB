#include<stdio.h>
int main()
{
   int a=1,i;
   char b[10]="SK", c[10]="TA10P", d='Z',e='Y';
   int z;
   scanf("%d",&z);
   switch(z)
   {
       case 1:  for(i=100000;i<100020;i++)  //1=EC
                 {
                    printf("%d%s%s%c%cE%d\n",a,b,c,d,e,i);
                 }
                 break;
       case 2:  for(i=100020;i<100040;i++)    //2=HY
                 {
                    printf("%d%s%s%c%cH%d\n",a,b,c,d,e,i);
                }
                 break;
       case 3:  for(i=100040;i<100060;i++)     //3=PU``
                {
                    printf("%d%s%s%c%cP%d\n",a,b,c,d,e,i);
                 }
                  break;
    }
}

