#include<stdio.h>
int main()
{
    int n=5;
    int arr[]={1,88,44,33,99};
    sort(n,arr);
    return 0;
}
void sort(int n, int* ptr)
{
    int i,j,t;
    for(i=0;i<n;i++)
    {
      for(j=0;j<n;j++)
      {
       if(*(ptr+i)< *(ptr+j))
       {
           t=*(ptr+i);
           *(ptr+i)=*(ptr+j);
            *(ptr+j)=t;

       }
      }

    }
    for(i=0;i<n;i++)
    {
        printf("elements:%d\n",*(ptr+i));
    }
}
