#include<stdio.h>
int main()
{
   int a=1,i;
   char b[10]="SK", c[10]="TA10P", d='Z',e='Y';
   char z[2];
   scanf("%s",&z);
   if(z=="EC")
   {
   for(i=100000;i<100020;i++)
    {
        printf("%d%s%s%c%cE%d\n",a,b,c,d,e,i);
        z=z+i;
    }

}
else if(z=="HY")
{
     for(i=100020;i<100040;i++)
     {
          printf("%d%s%s%c%cH%d\n",a,b,c,d,e,i);
     }
}

 else
 {
     for(i=100040;i<100060;i++)
     {
          printf("%d%s%s%c%cP%d\n",a,b,c,d,e,i);
     }
 }



}
