#include<stdio.h>
int main()
{
   int n;
   printf("enter the size of array: ");
   scanf("%d",&n);
   char a[n];
    //printf("%d",a);
    for(int i=0;i<n;i++)
    {
            scanf("%s",&a[i]);
    }
     printf("The values are : ");
    for(int i=0;i<n;i++)
    {
        printf("%c",a[i]);

    }
    return 0;
}



