
#include<stdio.h>
int main()
{

    int x;
    scanf("%d",&x);
    if(x>0)
        printf("greater\n");


    else if(x<10)
       printf("lesser\n");

    else
        printf("equal\n");

    printf("End");



}
