#include<stdio.h>
struct ccc
{
    int a;
    char b;
};
main()
{
    struct ccc k;


    struct ccc* ptr=&k;
    scanf("%d%s",&ptr->a,&ptr->b);
    printf("%d%c",(*ptr).a,(*ptr).b);
}
