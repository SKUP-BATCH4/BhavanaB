#include<stdio.h>
int main()
{

    int a=6;
    printf("%d",a);
}
