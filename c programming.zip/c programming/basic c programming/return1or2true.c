#include<stdio.h>
#include<stdbool.h>
bool one(int);
int main()
{
    int n;
    printf("Enter the no : ");
    scanf("%d",&n);
    printf("%d",one(n));
}
bool one(int a)
{

    if(a%20==18||a%20==19)
        return true;
    else
        return false;
}
