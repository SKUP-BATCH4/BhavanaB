#include<stdio.h>
int main()
{

    int a,b;
    scanf("%d %d",&a,&b);
    (a+b==6||a-b==6||a+b==-6||a-b==-6)?printf("6"):printf("not 6");

}

