#include<stdio.h>
int main()
{
int arg(int mess,int a[],int b[]){
    int aa=1;
    int bb=2;
    for(int i=0,j=0;i<11,j<11,j++)
    {
    if (a[i]!=b[j]){
        if(a[i]==0){
            return aa;
        }
        else {
            return bb;
        }}}}
        int main()
        {
    int a[]={1,1,1,1,0,1,0,1,1,0,0};
    int b[]={1,1,1,1,0,1,0,0,0,0,0};

    int s=arg(2,a,b);
    printf("%d",s)


