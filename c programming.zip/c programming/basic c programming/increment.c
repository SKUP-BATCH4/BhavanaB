#include<stdio.h>
int main()
{

//    int a=20,b=a;
//    printf("post inc %d\n",a++);
//    printf("%d\n",a);
//    printf("pre inc %d\n",++b);
//    printf("%d\n",b);
//    a++;
//    printf("post inc %d\n",a);
//    ++b;
//    printf("pre inc %d\n",b);
   int b=30;
   printf("post inc %d\n",b++);
   printf("pre inc %d\n",++b);

   char a='z';
   printf("post inc %c\n",a++);
   printf("%c\n",a);
   printf("pre inc %c\n",++a);
   printf("%c\n",a);
}
