#include<stdio.h>
extern int drama();
int x=10;
void main()
{
    drama();
    printf("In the auto_display %d\n",x);
}

