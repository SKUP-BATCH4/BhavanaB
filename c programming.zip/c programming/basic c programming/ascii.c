#include<stdio.h>
int main()
{

    char c;
    printf("enter the character : ");
    scanf("%c",&c);
    printf("the ascii value : %d",c);
    return 0;
}
