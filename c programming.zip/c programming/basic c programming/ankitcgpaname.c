#include<stdio.h>
struct  std
{
int name;
float cgpa;
char clroll;
};
void main()
{
struct std a[3];
scanf("%c\n%f\n%d",&a[0].name,&a[1].cgpa,&a[2].clroll);
printf("%c\n%f\n%d",a[0].name,a[1].cgpa,a[2].clroll);
}


