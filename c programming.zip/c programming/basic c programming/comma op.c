#include<stdio.h>
int main()
{
//    int a=2,b=10,c=2,x;
//    x=(a+b+c,b-a,b+a-c*a);
//
//    printf("%d",x);

int a=10;
int x;
x=(printf("%d\n %d\n",a++,--a),a++);
printf("%d",x);

}
