#include<stdio.h>
int main()
{
    //int a[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    int a[3][3];
    //a[0][1]=2;
    //a[0][3]=7;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {

            scanf("%d",&a[i][j]);
        }
    }
    printf("\n---------------------\n");
    for(int i=0;i<3;i++)
    {
        printf("|");
        for(int j=0;j<3;j++)
        {

            printf("%d ",a[i][j]);
        }
        printf("|");
        printf("\n");

    }
    printf("\n---------------------\n");
    printf("\n middle row \n");
    for(int j=0;j<3;j++)
        {

            printf("%d ",a[1][j]);
        }
        printf("\n---------------------\n");
    printf("\n middle column \n");
    for(int j=0;j<3;j++)
        {

            printf("%d ",a[1][j]);
        }
}
