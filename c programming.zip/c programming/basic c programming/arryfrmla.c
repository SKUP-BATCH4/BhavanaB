#include<stdio.h>
main()
{
    int i,n,count=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
          count++;
    }
   // for(i=0;i<n;i++)
    //{

        //printf("%d\n%d",a[i],sizeof(a[i]));
    //}
    printf("%d",count);
}
