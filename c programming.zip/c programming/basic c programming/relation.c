#include<stdio.h>
int main()
{
    int a=4,b=5;
    printf("%d\n",a&b);
    //printf("%d\n",a!b);
    printf("%d\n",~b);
    printf("%d\n",a<<b);
    printf("%d\n",a>>b);
    printf("%d\n",a|b);
}
