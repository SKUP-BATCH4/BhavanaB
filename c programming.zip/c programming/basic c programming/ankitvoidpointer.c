#include<stdio.h>
int main()
{
    void*vp;
    int a=5;
    float b=2.0;
    char c='c';
    void*vn;
    void*vd;
        vp=&c;
    vn=&a;
    vd=&b;

    printf("%c,%d,%f",*(char*)vp,*(int*)vn,*(float*)vd);


}
