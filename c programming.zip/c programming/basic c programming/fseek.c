#include<stdio.h>
#include<string.h>
int main()
{
    FILE * fp;
    fp=fopen("C:/Users/lenovo/Documents/hi.txt","r");
    //fprintf(fp,"Hii spoorti");
     char c[100];
    //fseek(fp,3,SEEK_SET);
    int lines=0;
    while(!feof(fp))
    {
         fgets(c,100,fp);
         lines++;
    }
    printf("%d",lines);

    fclose(fp);
}
