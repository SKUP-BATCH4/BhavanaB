#include<stdio.h>
int main()
{
    int i;
    for(i=1;i<=10;i++)
    {
        printf("32x%d=%d\n",i,32*i);
    }
}

