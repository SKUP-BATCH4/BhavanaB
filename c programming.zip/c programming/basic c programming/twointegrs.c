#include<stdio.h>
int main(){
int a=15,b=15;
printf("Enter the two integer");
scanf("%d",&a,&b);
(a+b)? printf("The sum is 30"):printf("The sum is not 30");



}
