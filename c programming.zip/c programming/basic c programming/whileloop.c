#include<stdio.h>
int main()
{
    int i=2;
    while(i<=10)
    {
        printf("%d",i);
        i=i+2;
    }

}
