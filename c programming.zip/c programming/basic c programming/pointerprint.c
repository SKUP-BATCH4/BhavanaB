#include<stdio.h>
int main()
{
    int a;
    float b;
    char c;
    int* ptr1=&a;
    float *ptr2=&b;
    char* ptr3=&c;
    scanf("%d %f %c", &a,&b,&c);
//    int* ptr1=&a;
//    float *ptr2=&b;
//    char* ptr3=&c;
    printf("values:%d %f %c\n",*ptr1,*ptr2,*ptr3);
    printf("adress:%x %x %x",ptr1,ptr2,ptr3);
}
