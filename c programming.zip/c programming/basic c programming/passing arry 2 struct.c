#include<stdio.h>
int avg(int[],int);
main()
{
    int average,size;
    int marks[5]={5,4,3,8,5};
    size=sizeof(marks)/sizeof(marks[0]);
    average=avg(marks,size);
    printf("%d",average);
}
int avg(int marks[],int a)
{
    int i,sum=0;
    int avg1;
    //a=sizeof(marks)/sizeof(marks[0]);
    for(i=0;i<a;i++)
    {
        sum=sum+marks[i];
    }
    printf("%d\n",sum);
    avg1=sum/a;
    return avg1;
}
