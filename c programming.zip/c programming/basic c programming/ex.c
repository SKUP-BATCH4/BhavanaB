#include<stdio.h>
void main()
{
    printf("%d\n",sizeof(double));
    printf("%d\n",sizeof(int));
    printf("%d\n",sizeof(float));
    printf("%d\n",sizeof(char));
    printf("%d\n",sizeof(long double));

    printf("%d\n",sizeof(long signed int));
    printf("%d\n",sizeof(long unsigned int));
    printf("%d\n",sizeof(short signed int));
    printf("%d\n",sizeof(short unsigned int));
    printf("%d\n",sizeof(short int));
    printf("%d\n",sizeof(long int));
    printf("%d\n",sizeof(signed int));
    printf("%d\n",sizeof(unsigned int));
    printf("%d\n",sizeof(signed char));
    printf("%d\n",sizeof(unsigned char));

//    long  int a=6;
//    printf("%ld\n",a);
}
