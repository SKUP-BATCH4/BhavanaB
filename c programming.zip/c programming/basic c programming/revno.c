#include<stdio.h>
int main()
{

    int rem,rev=0,a,n;
    scanf("%d",&n);
    while(n!=0)
    {
//       rem=n%10;
//       rev=rev*10+rem;
//       n=n/10;
         rem=n%10;
         printf("%d",rem);
         n=n/10;

    }

    //printf("%d",rev);
}

