//to print a value given by the user
#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter a number : ");
    scanf("%d %d",&a,&b);
    printf("the number is %d and %d",a,b);
    getch;
    return 0;
}
