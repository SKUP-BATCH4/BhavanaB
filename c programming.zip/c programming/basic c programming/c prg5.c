//program to take input as unformated and print as unformated
#include<stdio.h>
int main()
{
    char v;
    char c[10];
    gets(c);
    puts(c);
    puts("g v");

}
