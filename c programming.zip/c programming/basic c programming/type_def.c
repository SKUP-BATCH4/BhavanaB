#include<stdio.h>
int main()
{
    typedef name;
    name a= "vikram";
    printf("%s",a);

    printf("\n");

    typedef float ad;
    ad b= 4.5553456464;
    printf("%lf",b);
    return 0;
}
