#include<stdio.h>
float findsim(float,float,float);
int main()
{
    float x,y,z;
    printf("Enter the P,T,R : ");
    scanf("%f %f %f",&x,&y,&z);
    printf("the SI is %.3f",findsim(x,y,z));
}
float findsim(float p,float t,float r)
{
 float si;
 si=p*t*r/100;
 return si;
}
