#include<stdio.h>
int spy(int);
int a,b,sum=0,multi=1;
int main()
{

    printf("Enter the number to check spy or not:");
    scanf("%d",&a);
    spy(a);
}
    int spy(int a)
    {
       int rem=a%10;
        sum=rem+sum;
        a=a/10;
        multi=multi*rem;
        if(sum=multi){
            printf("spy no.");
        } else{
        printf("%d",&a);
        spy(a);
       // int spy(int a)
        }
    }

