#include<stdio.h>
float add(float , float , float );
int main()
{
float p,r,t;
printf("Enter the no");
scanf("%f%f%f",&p,&r,&t);
printf("%f",add(p,r,t));
}
float add(float p, float r, float t)
{
float s;
s=p*r*t/100;
return s;
}
