#include<stdio.h>
//int swap(int*,int*);
void main()

{
    int a, b;
    scanf("%d%d",&a,&b);
    swap(&a,&b);
printf("%d %d",a,b);

}

int swap(int *c ,int *d)

{
    *c=(*c)+(*d);
    *d=(*c)-(*d);
    *c=(*c)-(*d);
    // printf("%d %d\n",*c,*d);
}
