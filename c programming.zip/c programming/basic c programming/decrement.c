#include<stdio.h>
int main()
{
//
//    int a=20,b=a;
//    printf("post dec %d\n",a--);
//    printf("%d\n",a);
//    printf("pre dec %d\n",--b);
//    printf("%d\n",b);
//    a--;
//    printf("post dec %d\n",a);
//    --b;
//    printf("pre dec %d\n",b);
//   int a=30;
//   printf("post dec %d\n",a--);
//   printf("%d\n",a);
//   printf("pre dec %d\n",--a);
//   printf("%d\n",a);
//
   char a='$';
   printf("post inc %c\n",a--);
   printf("%c\n",a);
   printf("pre inc %c\n",--a);
   printf("%c\n",a);
}

