#include<stdio.h>
int main()
{
int a=6,b=5;
printf("Enter the two integers");
scanf("%d %d",&a,&b);
a%2==0?printf("even"):printf("odd");
}
