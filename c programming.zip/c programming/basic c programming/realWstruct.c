#include<stdio.h>
struct emp
{
    char name[20];
    int id;
    int age;
    float kg;
};
int main()
{
    struct emp e1={"vikram",20220845,22,48.7};
    struct emp e2={"ankit",20220847,23,57.2};
    printf("%s %d %d %.2f\n",e1.name,e1.id,e1.age,e1.kg);
    printf("%s %d %d %.2f\n",e2.name,e2.id,e2.age,e2.kg);
}
