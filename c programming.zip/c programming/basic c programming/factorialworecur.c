#include<stdio.h>
int add ();
int main()
{
    int p,r,t;
    printf("Enter the no:");
    scanf("%d%d%d",&p,&r,&t);
    printf("%d",add());



}
int add()
{


 int p=80,t=2,r=5,s;
s=(p*r*t)/100;
return s;
}

