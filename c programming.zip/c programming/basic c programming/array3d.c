#include<stdio.h>
int main()
{
    int a[2][3][3];
//    for(int i=0;i<2;i++)
//    {
//
//        for(int j=0;j<3;j++)
//        {
//            for(int k=0;k<3;k++)
//            {
//                scanf("%d",&a[i][j][k]);
//            }
//
//        }
//
//    }
    for(int i=0;i<2;i++)
    {

        for(int j=0;j<3;j++)
        {
            for(int k=0;k<3;k++)
            {
                a[i][j][k]=0;
            }

        }

    }

    for(int k=0;k<3;k++)
    {
        scanf("%d",&a[0][2][k]);
    }
printf("\n---------------------------------------\n");
    for(int i=0;i<2;i++)
    {

        for(int j=0;j<3;j++)
        {
            for(int k=0;k<3;k++)
            {
                printf("%d ",a[i][j][k]);
            }
            printf("\n");

        }

        printf("\n");

    }
}

