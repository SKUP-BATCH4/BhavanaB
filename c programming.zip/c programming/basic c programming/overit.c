#include<stdio.h>
int overit(int*, int*);
int main()
{
    int a,b;
    printf("Enter the no :");
    scanf("%d",&a);
    printf("Enter the no :");
    scanf("%d",&b);
     FILE * fp;
     fp=fopen("C:/Users/lenovo/Documents/overit.txt","w");

    fprintf(fp,"The number nearest to 21 is : %d",overit(&a,&b));
fclose(fp);
}
int overit(int *a, int *b)
{

    if(*a<=21 && *b<=21)
    {
        int m=21-*a;
        int n=21-*b;
        if(m>n)
        {
            return *b;
        }
        else
        {
            return *a;
        }
    }
    else
    {
        return 0;
    }

}
