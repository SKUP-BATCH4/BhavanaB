
#include<stdio.h>
int main()
{

    int x;
    scanf("%d",&x);
    if(x)
        printf("1");


    else
        printf("0");


}
