#include<stdio.h>
int a=10,b=5;
int main()
{

    //int a=10;
    a+=b;
    printf("%d\n",a);
    a-=b;
    printf("%d\n",a);
    a*=b;
    printf("%d\n",a);
    a/=b;
    printf("%d\n",a);
    a%=b;
    printf("%d\n",a);
}
