#include<stdio.h>
int main()
{
    int a ,b,y;
    char op;
    printf("choose\n + for add\n - for sub\n * for multiply\n / for division\n choose: ");
    scanf("%c",&op);
    printf("enter a: ");
    scanf("%d",&a);
    printf("enter b: ");
    scanf("%d",&b);

    switch(op)
    {
        case '+': y=a+b;
             printf("The addition is %d",y);
        break;
        case '-': y=a-b;
             printf("The difference is %d",y);
        break;
        case '*': y=a*b;
            printf("The multiplication is %d",y);
        break;
        case '/': y=a/b;
             printf("The division is %d",y);
        break;
        default: printf("Invalid input");
    }
}
