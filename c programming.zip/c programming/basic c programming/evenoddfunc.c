#include<stdio.h>
void eord(int);
int main()
{

    int a;
    printf("Enter values : ");
    scanf("%d",&a);
    eord(a);



}
void eord(int a)
{

    int b=a/2;
    if(2*b+1==a)
        printf("Odd");
    else
        printf("Even");
}
