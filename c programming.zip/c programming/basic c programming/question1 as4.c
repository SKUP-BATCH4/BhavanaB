#include<stdio.h>
int main()
{
int arg1,i,c,size;
int arg2[11];
while (c=size)
printf("enter the value for arbitration %d",c);
scanf("%d %d",&arg1,&arg2);
for (i=0;i<c;i++){

    printf("the arbitration is change ");
}


if (arg1<arg2){
    printf("won the arbitration ");
    //i++;
   // return 1;
}
else
{
    printf("no");

    return 1;
}
//else {

   // printf("failure");
}

//for (i=0;i<sizeof(arg1);i++)
//{
    //if (arg2<=arg1){
//printf("the value of arg1 is %d\n ",arg2);



