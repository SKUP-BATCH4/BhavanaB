#include<stdio.h>

void main()
{

    char a[20]="kavyasri";
    char b[10]="niharika";

  sl(a);
  sm(b);

}

void sl(char a[])
{

        printf("%d\n",strlen(a));


}
void sm(char b[])
{

        printf("%s",strupr(b));


}

