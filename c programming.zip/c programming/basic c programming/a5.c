#include<stdio.h>
#define max 50
int top=-1;
int arr[max];

void push(int item)
{
    if(top==max-1)
    {
        printf("stack overflow");
        return;
    }
    else
        {
            arr[++top]=item;
    printf("push element is %d",item);
        }
}
