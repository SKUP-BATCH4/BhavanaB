#include<stdio.h>
int main()
{
   int n;
   printf("enter the size of array: ");
   scanf("%d",&n);
   int a[n];
    //printf("%d",a);
    for(int i=0;i<n;i++)
    {
            scanf("%d",&a[i]);
    }
     printf("The values are : ");
    for(int i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
}
