#include<stdio.h>
int func()
{
    if (n==1)
    {

        return1;
    }
    else
        {
        return 1 for(n-1);
        int main()
        {

            int n=3
            if("%d", function(n));
            int main()
            {
                int n=3
                printf("%d,f(n)");
            }
            func(3)
            if func(3-1)
                if func(2-1)
                func 1
            }
