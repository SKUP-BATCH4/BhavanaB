#include<stdio.h>
int main(){

//    int a=52,b=4;
//    printf("%d\n",!(a<b));
//    printf("%d\n",(a<b));
//    printf("%d\n",!b);
//    printf("%d",~b);
     float a=0.0;
     printf("%f",!a);


}
