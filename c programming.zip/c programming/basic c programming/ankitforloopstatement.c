#include<stdio.h>
int main()
{
char a;
float b;
int c;
int i;
for(i=0;i<1;i++;)
{



printf("gfhgfjghj");
scanf("%c%f%d",&a,&b,&c);
printf("%c\n%f\n%d\n",a,b,c);

}
