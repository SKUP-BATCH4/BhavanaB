#include<stdio.h>
int main()
{
    char abc[10];
printf("Enter the string");
scanf("%s",&abc);
 for(int i=0;i<1;i++)
    {
    //if( (abc[i]>='a') || (abc[i]<='z') )
      // {
       printf("%s",strupr(abc));
       //}
       //else if ('A')
 }
 }
