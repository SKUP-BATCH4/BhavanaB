#include<stdio.h>
typedef struct student
{
    int a;
    float b;
}ankt,roy;
main()
{
ankt r={45,5.5};
roy f={33,3.3};
  printf("%d\n%f\n%d\n%f",r.a,r.b,f.a,f.b);
}
