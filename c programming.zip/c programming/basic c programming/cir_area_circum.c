#include<stdio.h>
#define PI 3.142
float area(float a)
{
    float res;
     res=PI*a*a;
    return res;

}
float circum(float b)
{
    float res;
    res=2*PI*b;
    return res;
}
int main()
{
    float r;
    printf("Enter radius : ");
    scanf("%f",&r);

    printf("area of circle = %.3f",area(r));
    printf("\n area of circumference = %.3f",circum(r));
}



