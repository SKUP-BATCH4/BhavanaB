
#include<stdio.h>
int main()
{

    int a,b,c;
    printf("enter the values for a,b,c : ");
    scanf("%d %d %d",&a,&b,&c);
    if(a==b&&b==c&&c==a)
        printf("20");
    else if(a==b||b==c||c==a)
        printf("10");
    else
        printf("0");



}
