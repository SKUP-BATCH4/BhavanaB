#include<stdio.h>
int main()
{
    int i,a,sum=0;
    for(i=2;i<=10;i=i+2)
    {
        printf("%d\n",i);

    }
   //+ printf("The total sum is %d",sum);
}

