#include<stdio.h>
char name(char*);
void main()
{
    char a[10];
    scanf("%s",a);
    char (*p)(char[10])=name;

    a[10]=(*p)(a);


}
char name(char* a)
{
     printf("%s",a);
}
