#include<stdio.h>
int main()
{

    int a,b;
    printf("enter the values of A and B : ");
    scanf("%d %d",&a,&b);
    (a==30||b==30||a+b==30)?printf("True"):printf("False");
}
