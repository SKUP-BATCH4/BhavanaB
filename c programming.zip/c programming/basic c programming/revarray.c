#include<stdio.h>
int main()
{

   int a[3];
   int b[3];
    printf("The values : ");
    for(int i=0;i<3;i++)
    {
            scanf("%d",&a[i]);
    }
    for(int i=2;i>=0;i--)
    {
        b[2-i]=a[i];
    }
//     printf("The values in reverse order are : ");
//    for(int i=2;i>=0;i--)
//    {
//        printf("%d ",a[i]);
//
//    }
     printf("The values in reverse order are : ");
    for(int i=0;i<3;i++)
    {
        printf("%d ",b[i]);

    }

    return 0;
}




