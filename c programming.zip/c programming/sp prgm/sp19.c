//prgm to perform increment //
int main()
{

    int a=90,b=80;
    //a++;
    printf("shows post increment : %d\n",++a);
    //++b;
    printf("shows pre increment : %d\n",b++);
}
