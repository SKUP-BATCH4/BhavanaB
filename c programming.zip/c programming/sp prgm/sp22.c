//incr and decr//
int main()
{
int x=10, y=10,z=20,a;
a=x++ - --y + ++z - --y - ++x;
printf("x is %d\n y is %d\n z is %d\n a is %d",x,y,z,a);
}
