int main()
{
char a='b';
printf("%c",a+='h');
}
