int main()
{

    int y=0;
    printf("%d",!y);
}
