int main()
{
    int a=8,b=6;
    printf("%d\n",(a<b)^(a>b));
    printf("%d\n",(a==b)^(a>b));

}
