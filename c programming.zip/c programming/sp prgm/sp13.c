#include<stdio.h>
int main()
{
int a=10,c;
c=!(a);
printf("%d",c);
}
