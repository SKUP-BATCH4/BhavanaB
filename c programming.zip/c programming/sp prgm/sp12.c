int main()
{
 int a;
 a=-2147483650;
 printf("%d",a);
}
