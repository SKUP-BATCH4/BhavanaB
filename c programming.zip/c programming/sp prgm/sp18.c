int main()
{
 char x='r',y='r',z;
 z=(x==y)?printf("x is greater than y"):printf("y is greater than x");
}
