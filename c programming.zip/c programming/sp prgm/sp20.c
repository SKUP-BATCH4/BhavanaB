//prgm to perform increment on same value//
int main()
{
    float a=5.2;
    printf("%f\n",--a);
    printf("%f\n",--a);
}
