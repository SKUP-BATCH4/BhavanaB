#include<stdio.h>
int main()
{
    int a=8,b=5
    ;
     a=a+b;
     b=a-b;
     a=a-b;
     printf(" a is %d\n b is %d",a,b);
}

