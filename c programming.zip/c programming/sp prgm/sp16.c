int main()
{
float a=10.2, b=1.2;
printf("%f\n",(a==b)&&b);
printf("%f\n",(a>=b)&&b);
printf("%f\n",(a<=b)&&b);
printf("%f\n",(a!=b)&&b);
}

