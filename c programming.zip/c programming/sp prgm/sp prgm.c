#include<stdio.h>
int main()

{
    typedef sp;
    sp a="hello";
    printf("%s",a);

}
