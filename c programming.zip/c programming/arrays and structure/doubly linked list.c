

#include<stdio.h>

struct node
{
    struct node *prev;

};


